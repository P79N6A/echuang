<?php 
/**
 * 菜单
 * 
 */
defined('In33hao') or exit('Access Invalid!');
//$_menu['service_center'] = array (
//	'name' => '服务中心',
//    'child' => array(
//        array(
//            'name' => '服务中心', 
//            'child' => array(
//                'service' => '服务中心',
//        	)
//    	),
//    )
//);