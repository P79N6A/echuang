<?php defined('In33hao') or exit('Access Invalid!');?>

<div class="page">
    <div class="fixed-bar">
        <div class="item-title">
            <div class="subject">
                <h3>扩大范围记录</h3>
                <h5>普通用户扩大范围列表管理</h5>
            </div>
        </div>
        <!-- 操作说明 -->
        <div class="explanation" id="explanation">
            <div class="title" id="checkZoom"><i class="fa fa-lightbulb-o"></i>
                <h4 title="">操作说明</h4>
                <span id="explanationZoom" title=""></span>
            </div>
            <ul>
                <li>通过会员申请管理列表，你可以进行查看，管理会员资料</li>
                <li>你可以根据条件搜索会员，然后查看相应的会员资料</li>
            </ul>
        </div>
        <div id="flexigrid"></div>
    </div>
    <script type="text/javascript">
        $(function(){
            $("#flexigrid").flexigrid({
                url: 'index.php?act=expand_area_record&op=get_xml',
                colModel : [
                    {display: '用户名称', name : 'member_name', width : 100, sortable : true, align: 'center'},
                    {display: '用户手机', name : 'member_mobile', width : 200, sortable : true, align: 'center'},
                    {display: '成功分享用户数量', name : 'recommended_registration', width : 200, sortable : true, align: 'center'},
                    {display: '扩大范围（公里）', name : 'add_red_envelopes_range', width : 200, sortable : true, align: 'center'},
                    {display: '增加红包数', name : 'add_red_envelopes_num', width : 100, sortable : true, align: 'center'},
                    {display: '时间', name : 'add_time', width : 200, sortable : true, align: 'center'}
                ],
                buttons : [
                    {display: '<i class="fa fa-file-excel-o"></i>导出数据', name : 'csv', bclass : 'csv', title : '导出Excel文件', onpress : fg_operation }
                ],
                searchitems : [
                    {display: '用户名', name : 'member_name'},
                    {display: '手机号', name : 'member_mobile'}
                ],
                sortname: "order_number",
                sortorder: "desc",
                title: '扩大范围记录列表'
            });
        });

        function fg_operation(name, bDiv) {
            if (name == 'csv') {
                if ($('.trSelected', bDiv).length == 0) {
                    if (!confirm('您确定要下载全部数据吗？')) {
                        return false;
                    }
                }
                var itemids = new Array();
                $('.trSelected', bDiv).each(function(i){
                    itemids[i] = $(this).attr('data-id');
                });
                fg_csv(itemids);
            }
        }
        function fg_csv(ids) {
            id = ids.join(',');
            window.location.href = $("#flexigrid").flexSimpleSearchQueryString()+'&op=export_step1&id=' + id;
        }
    </script>