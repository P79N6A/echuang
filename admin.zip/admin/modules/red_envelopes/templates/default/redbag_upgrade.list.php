<?php defined('In33hao') or exit('Access Invalid!');?>

<div class="page">
    <div class="fixed-bar">
        <div class="item-title">
            <div class="subject">
                <h3>会员升级管理</h3>
                <h5>普通用户申请成为会员列表管理</h5>
            </div>
    </div>
    <!-- 操作说明 -->
    <div class="explanation" id="explanation">
        <div class="title" id="checkZoom"><i class="fa fa-lightbulb-o"></i>
            <h4 title="">操作说明</h4>
            <span id="explanationZoom" title=""></span>
        </div>
        <ul>
            <li>通过会员申请管理列表，你可以进行查看，管理会员资料</li>
            <li>你可以根据条件搜索会员，然后查看相应的会员资料</li>
        </ul>
    </div>
    <div id="flexigrid"></div>
</div>
<script type="text/javascript">
    $(function(){
        $("#flexigrid").flexigrid({
            url: 'index.php?act=member_upgrade&op=get_xml',
            colModel : [
                {display: '订单号', name : 'order_number', width : 150, sortable : true, align: 'center'},
                {display: '支付单号', name : 'payment_number', width : 150, sortable : true, align: 'center'},
                {display: '用户名称', name : 'member_name', width : 100, sortable : true, align: 'center'},
                {display: '用户手机', name : 'member_mobile', width : 150, sortable : true, align: 'center'},
                {display: '金额（元）', name : 'money', width : 100, sortable : true, align: 'center'},
                {display: '支付状态', name : 'state', width : 100, sortable : true, align: 'center'},
                {display: '支付方式', name : 'mode', width : 100, sortable : true, align: 'center'},
                {display: '支付时间', name : 'addtime', width : 150, sortable : true, align: 'center'}
            ],
            buttons : [
                {display: '<i class="fa fa-file-excel-o"></i>导出数据', name : 'csv', bclass : 'csv', title : '导出Excel文件', onpress : fg_operation }
            ],
            searchitems : [
                {display: '订单号', name : 'order_number'},
                {display: '用户名称', name : 'member_name'},
                {display: '手机号', name : 'member_mobile'}
            ],
            sortname: "order_number",
            sortorder: "desc",
            title: '升级会员管理列表'
        });
    });

    function fg_operation(name, bDiv) {
        if (name == 'csv') {
            if ($('.trSelected', bDiv).length == 0) {
                if (!confirm('您确定要下载全部数据吗？')) {
                    return false;
                }
            }
            window.location.href = 'index.php?act=member_upgrade&op=export_step1';
        }
    }
</script>