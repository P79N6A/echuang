<?php defined('In33hao') or exit('Access Invalid!');?>

<div class="page">
    <div class="fixed-bar">
        <div class="item-title">
            <div class="subject">
                <h3>城主管理</h3>
                <h5>城主列表管理</h5>
            </div>
        </div>
        <!-- 操作说明 -->
        <div class="explanation" id="explanation">
            <div class="title" id="checkZoom"><i class="fa fa-lightbulb-o"></i>
                <h4 title="">操作说明</h4>
                <span id="explanationZoom" title=""></span>
            </div>
            <ul>
                <li>通过城主管理列表，你可以进行查看，管理城主资料</li>
                <li>你可以根据条件搜索城主，然后查看相应的城主资料</li>
            </ul>
        </div>
        <div id="flexigrid"></div>
    </div>
    <script type="text/javascript">
        $(function(){
            $("#flexigrid").flexigrid({
                url: 'index.php?act=city_owner_manage&op=get_xml',
                colModel : [
                    {display: '单号', name : 'order_number', width : 200, sortable : true, align: 'center'},
                    {display: '城主名称', name : 'member_name', width : 100, sortable : true, align: 'center'},
                    {display: '城主手机', name : 'member_mobile', width : 200, sortable : true, align: 'center'},
                    {display: '城主区域', name : 'area_id', width : 200, sortable : true, align: 'center'},
                    {display: '所属时间段', name : 'time_of_ownership', width : 100, sortable : true, align: 'center'},
                    {display: '抢占时间', name : 'addtime', width : 200, sortable : true, align: 'center'}
                ],
                buttons : [
                    {display: '<i class="fa fa-file-excel-o"></i>导出数据', name : 'csv', bclass : 'csv', title : '导出Excel文件', onpress : fg_operation }
                ],
                searchitems : [
                    {display: '订单号', name : 'order_number'},
                    {display: '城主名称', name : 'member_name'},
                    {display: '手机号', name : 'member_mobile'}
                ],
                sortname: "order_number",
                sortorder: "desc",
                title: '城主管理列表'
            });
        });

        function fg_operation(name, bDiv) {
            if (name == 'csv') {
                if ($('.trSelected', bDiv).length == 0) {
                    if (!confirm('您确定要下载全部数据吗？')) {
                        return false;
                    }
                }
                window.location.href = 'index.php?act=city_owner_manage&op=export_step1';
            }
        }
    </script>