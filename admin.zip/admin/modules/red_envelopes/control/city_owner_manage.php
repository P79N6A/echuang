<?php
/**
 * 扩大范围记录
 *
 */
defined('In33hao') or exit('Access Invild!');
class city_owner_manageControl extends SystemControl {


    public function __construct()
    {
        parent::__construct();
    }

    public function indexOp()
    {
        $this->city_owner_manageOp();
    }

    /**
     * 城主记录列表
     */
    public function city_owner_manageOp(){
        Tpl::setDirquna('red_envelopes');
        Tpl::showpage('redbag_city.list');
    }

    public function get_xmlOp()
    {
        // print_r($_REQUEST);die();
        $member=Model('member');
        $return=Model('red_city_owner_manage');
        $data = array();
        if ($_POST['query'] != '') {
            $condition[$_POST['qtype']] = array('like', '%' . $_POST['query'] . '%');
        }
        if($_POST['qtype']=='member_name_return' ||$_POST['qtype']=='member_mobile_return'){
            if($_POST['qtype']=='member_name_return'){
                $name='member_name';
            }else{
                $name='member_mobile';
            }
            $where[$name] = array('like', '%' . $_POST['query'] . '%');
            $membdefind=$return->getwhere($where);
            if($membdefind!=false){
                foreach ($membdefind as $key => $value) {
                    $returncondition['inviter_id']=$value['member_id'];
                    $list[] = $return->getPdRechargeList($returncondition, $pagesize = '', $fields = '*', $order = '', $limit = '');
                }
                $list=array_filter($list);
                foreach ($list as $key =>$v){
                    $return_list[]=$v[0];
                }
            }
        }else{
            $return_list = $return->getPdRechargeList($condition, $pagesize = '', $fields = '*', $order = '', $limit = '');
        }
        $data = array();
        $data['now_page'] = 1;
        $data['total_num'] = count($return_list);
        foreach ($return_list as $v) {
            $membde_mobile=$member->getMemberInfoByID($v['member_id']);
            $addtime=date("Y-m-d H:i:s",$v['addtime']);
            $param = array();
            $param['order_number'] = $v['order_number'];
            $param['member_name_return'] = $membde_mobile['member_name'];
            $param['member_mobile_return'] = $membde_mobile['member_mobile'];
            $param['area_name'] = $v['area_name'];
            $param['time_of_ownership'] = $v['time_of_ownership'];
            $param['addtime'] = $addtime;
            $data['list'][$v['']] = $param;
        }
        Tpl::flexigridXML($data);
    }

    /**
     * 导出城主
     *
     */
    public function export_step1Op() {
        $return=Model('red_city_owner_manage');
        $return_list=$return->getPdRechargeList($condition, $pagesize = '', $fields = '*', $order = '', $limit = '');
        $this->createExcel($return_list);
    }

    /**
     * 生成导出城主excel
     *
     * @param array $data
     */
    private function createExcel($data = array()) {
        Language::read('export');
        import('libraries.excel');
        $excel_obj = new Excel();
        $excel_data = array();
        // 设置样式
        $excel_obj->setStyle(array('id' => 's_title', 'Font' => array('FontName' => '宋体', 'Size' => '12', 'Bold' => '1')));
        // header
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '单号');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '城主名称');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '城主手机');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '城主区域');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '所属时间段');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '抢占时间');

        foreach ((array) $data as $k => $v) {
            $tmp = array();
            $tmp[] = array('data' => $v['order_number']);
            $tmp[] = array('data' => $v['member_name']);
            $tmp[] = array('data' => $v['member_mobile']);
            $tmp[] = array('data' => $v['area_name']);
            $tmp[] = array('data' => $v['time_of_ownership']);
            $tmp[] = array('data' => date('Y-m-d H:i:s', $v['addtime']));
            $excel_data[] = $tmp;
        }
        $excel_data = $excel_obj->charset($excel_data, CHARSET);
        $excel_obj->addArray($excel_data);
        $excel_obj->addWorksheet($excel_obj->charset('城主管理', CHARSET));
        $excel_obj->generateXML($excel_obj->charset('城主管理', CHARSET) . $_GET['curpage'] . '-' . date('Y-m-d-H', time()));
    }

}