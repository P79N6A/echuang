<?php
/**
 * 扩大范围记录
 *
 */
defined('In33hao') or exit('Access Invild!');
class expand_area_recordControl extends SystemControl {


    public function __construct()
    {
        parent::__construct();
    }

    public function indexOp()
    {
        $this->expand_area_recordOp();
    }

    /**
     * 扩大范围记录列表
     */
    public function expand_area_recordOp(){
        Tpl::setDirquna('red_envelopes');
        Tpl::showpage('redbag_expand.list');
    }

    public function get_xmlOp()
    {   
        $area_record=Model('red_expand_area_record');
        $location=Model('red_envelopes_location');
        $the_scope=Model('red_expand_the_scope');
        $getRow=$the_scope->red_getRow('1');
        $locationrow=$location->red_getRow('1');
        $list=$area_record->getselect();
        foreach ($list as $key => $value) {
            $data['member_id']=$value['member_id'];
            $array=$area_record->get($data);
            $list[$key]['count']=$array;
            if($list[$key]['count']>=$getRow['recommended_registration']){
                $integer=floor($list[$key]['count']/$getRow['recommended_registration']);
                $range=$getRow['add_red_envelopes_range']*$integer;
                $num=$getRow['add_red_envelopes_num']*$integer;
                $list[$key]['location_range']=$range;
                $list[$key]['location_num']=$num;
                $list_record=$list;
            }
        }
        $data = array();
        $data['now_page'] = 1;
        $data['total_num'] = count($list_record);
        foreach ($list_record as $v) {
            $addtime=date("Y-m-d H:i:s",$v['addtime']);
            $param = array();
            $param['member_name_return'] = $v['member_name'];
            $param['member_mobile_return'] = $v['member_mobile'];
            $param['count'] = $v['count'];
            $param['location_range'] = $v['location_range'];
            $param['location_num'] = $v['location_num'];
            $param['addtime'] = $addtime;
            $data['list'][$v['member_id']] = $param;
        }
        Tpl::flexigridXML($data);
    }

    /**
     * 导出扩大范围记录
     *
     */
    public function export_step1Op() {
        $member=Model('');
        $return=Model('');
        $return_list=$return->getarray();
        foreach ($return_list as $key => $value) {
            $membde_mobile=$member->getMemberInfoByID($value['inviter_id']);
            $return_list[$key]['member_name_return']=$membde_mobile['member_name'];
            $return_list[$key]['member_mobile_return']=$membde_mobile['member_mobile'];
        }
        $this->createExcel($return_list);
    }

    /**
     * 生成导出扩大范围记录excel
     *
     * @param array $data
     */
    private function createExcel($data = array()) {
        Language::read('export');
        import('libraries.excel');
        $excel_obj = new Excel();
        $excel_data = array();
        // 设置样式
        $excel_obj->setStyle(array('id' => 's_title', 'Font' => array('FontName' => '宋体', 'Size' => '12', 'Bold' => '1')));
        // header
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '用户名称');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '用户手机');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '成功分享用户数量');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '扩大范围（公里）');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '增加红包数');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '时间');

        foreach ((array) $data as $k => $v) {
            $tmp = array();
            $tmp[] = array('data' => $v['member_name_return']);
            $tmp[] = array('data' => $v['member_mobile_return']);
            $tmp[] = array('data' => $v['']);
            $tmp[] = array('data' => $v['']);
            $tmp[] = array('data' => $v['']);
            $tmp[] = array('data' => date('Y-m-d H:i:s', $v['']));
            $excel_data[] = $tmp;
        }
        $excel_data = $excel_obj->charset($excel_data, CHARSET);
        $excel_obj->addArray($excel_data);
        $excel_obj->addWorksheet($excel_obj->charset('扩大范围记录', CHARSET));
        $excel_obj->generateXML($excel_obj->charset('扩大范围记录', CHARSET) . $_GET['curpage'] . '-' . date('Y-m-d-H', time()));
    }

}