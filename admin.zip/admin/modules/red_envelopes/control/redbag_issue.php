<?php
/**
 * 红包审核记录
 *
 */
defined('In33hao') or exit('Access Invild!');
class redbag_issueControl extends SystemControl {


    public function __construct()
    {
        parent::__construct();
    }

    public function indexOp()
    {
        $this->redbag_manageOp();
    }

    /**
     * 红包审核记录列表
     */
    public function redbag_manageOp(){
        Tpl::setDirquna('red_envelopes');
        Tpl::showpage('redbag_examine.list');
    }

    public function get_xmlOp()
    {
        // print_r($_REQUEST);die();
        $return=Model('red_redbag_issue');
        $data = array();
        if ($_POST['query'] != '') {
            $condition[$_POST['qtype']] = array('like', '%' . $_POST['query'] . '%');
        }
        if($_POST['qtype']=='member_name_return' || $_POST['qtype']=='member_mobile_return'){
            if($_POST['qtype']=='member_name_return'){
                $name='member_name';
            }else{
                $name='member_mobile';
            }
            $where[$name] = array('like', '%' . $_POST['query'] . '%');
            $membdefind=$return->getwhere($where);
            if($membdefind!=false){
                foreach ($membdefind as $key => $value) {
                    $returncondition['inviter_id']=$value['member_id'];
                    $list[] = $return->getPdRechargeList($returncondition, $pagesize = '', $fields = '*', $order = '', $limit = '');
                }
                $list=array_filter($list);
                foreach ($list as $key =>$v){
                    $return_list[]=$v[0];
                }
            }
        }else{
            $return_list = $return->getPdRechargeList($condition, $pagesize = '', $fields = '*', $order = '', $limit = '');
        }
        $data = array();
        $data['now_page'] = 1;
        $data['total_num'] = count($return_list);
        foreach ($return_list as $v) {
            $addtime=date("Y-m-d H:i:s",$v['addtime']);
            $param = array();
            if ($v['state'] == 0) {
                $param['operation'] = "<a class='btn blue' href='index.php?act=redbag_issue&op=redbag_modify&id=" . $v['red_envelopes_id'] . "&state=2'><i class='fa fa-pencil-square-o'></i>通过</a><a class='btn blue' href='index.php?act=redbag_issue&op=redbag_modify&id=" . $v['red_envelopes_id'] . "&state=1'><i class='fa fa-pencil-square-o'></i>拒绝</a><a class='btn blue' href='index.php?act=redbag_issue&op=see&id=" . $v['red_envelopes_id'] . "'><i class='fa fa-pencil-square-o'></i>查看</a>";
            } else {
                if ($v['state'] == 2) {
                    $param['operation'] = "<span style='color: #3AA55A;'>已审核</span><a class='btn blue' href='index.php?act=redbag_issue&op=see&id=" . $v['red_envelopes_id'] . "'><i class='fa fa-pencil-square-o'></i>查看</a>";
                } else {
                    $param['operation'] = "<span style='color: #ff3c00;'>已拒绝</span><a class='btn blue' href='index.php?act=redbag_issue&op=&id=see" . $v['red_envelopes_id'] . "'><i class='fa fa-pencil-square-o'></i>查看</a>";
                }
            }
            $param['red_envelopes_order_number'] = $v['red_envelopes_order_number'];
            $param['member_mobile'] = $v['member_mobile'];
            $param['money'] = $v['money'];
            $param['red_envelopes_num'] = $v['red_envelopes_num'];
            $param['area_name'] = $v['red_envelopes_province'].$v['red_envelopes_city'].$v['red_envelopes_area'];
            $param['age']=$v['left_age'].'-'.$v['right_age'];
            $param['name']=$v['name'];
            $param['red_envelopes_picture']=$v['red_envelopes_picture'];
            $param['red_envelopes_content']=$v['red_envelopes_content'];
            $param['link']=$v['link'];
            $data['list'][$v['red_envelopes_id']] = $param;
        }
        Tpl::flexigridXML($data);
    }

     /*
     *  红包审核
     */   

    public function redbag_modifyOp(){
        $issue=Model('red_redbag_issue');
        $data['state']=$_GET['state'];
        $where['red_envelopes_id']=$_GET['id'];
        $return=$issue->modify($where,$data);
        if($return==false){
            showMessage('执行失败','index.php?act=redbag_issue&op=redbag_manage');
        }else{
            showMessage('执行成功','index.php?act=redbag_issue&op=redbag_manage');
        }
    }
    /*
    * 查看详情
    */
    public function seeOp(){
        $return=Model('red_redbag_issue');
        $condition['red_envelopes_id']=$_GET['id'];
        $return_list = $return->getPdRechargeList($condition, $pagesize = '', $fields = '*', $order = '', $limit = '');
        Tpl::output('info',$return_list);
        Tpl::setDirquna('red_envelopes');
        Tpl::showpage('redbag_examine.see');
    }

    /**
     * 导出红包审核
     *
     */
    public function export_step1Op() {
        $return=Model('red_redbag_issue');
        $return_list = $return->getPdRechargeList($condition, $pagesize = '', $fields = '*', $order = '', $limit = '');
        $this->createExcel($return_list);
    }

    /**
     * 生成导出红包审核excel
     *
     * @param array $data
     */
    private function createExcel($data = array()) {
        Language::read('export');
        import('libraries.excel');
        $excel_obj = new Excel();
        $excel_data = array();
        // 设置样式
        $excel_obj->setStyle(array('id' => 's_title', 'Font' => array('FontName' => '宋体', 'Size' => '12', 'Bold' => '1')));
        // header
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '红包单号');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '用户手机');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '红包金额');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '红包个数');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '定位范围');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '年龄阶段');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '爱好');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '广告词');
        $excel_data[0][] = array('styleid' => 's_title', 'data' => '链接');

        foreach ((array) $data as $k => $v) {
            $tmp = array();
            $tmp[] = array('data' => $v['red_envelopes_order_number']);
            $tmp[] = array('data' => $v['member_mobile']);
            $tmp[] = array('data' => $v['money']);
            $tmp[] = array('data' => $v['red_envelopes_num']);
            $tmp[] = array('data' => $v['red_envelopes_province'].$v['red_envelopes_city'].$v['red_envelopes_area']);
            $tmp[] = array('data' => $v['left_age'].'-'.$v['right_age']);
            $tmp[] = array('data' => $v['name']);
            $tmp[] = array('data' => $v['red_envelopes_content']);
            $tmp[] = array('data' => $v['link']);
            $excel_data[] = $tmp;
        }
        $excel_data = $excel_obj->charset($excel_data, CHARSET);
        $excel_obj->addArray($excel_data);
        $excel_obj->addWorksheet($excel_obj->charset('红包列表', CHARSET));
        $excel_obj->generateXML($excel_obj->charset('红包列表', CHARSET) . $_GET['curpage'] . '-' . date('Y-m-d-H', time()));
    }

}