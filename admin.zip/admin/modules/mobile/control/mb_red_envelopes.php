<?php
/**
 * 下载设置
 *
 *
 *
 *
 * @
 * @license
 * @link
 */



defined('In33hao') or exit('Access Invalid!');
class mb_red_envelopesControl extends SystemControl{
    public function __construct(){
        parent::__construct();
    }

    public function indexOp() {

    }
}
