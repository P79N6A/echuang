<?php
defined('In33hao') or exit('Access Invalid!');

$lang['admin_log_man']			= '操作人';
$lang['admin_log_do']			= '行為';
$lang['admin_log_dotime']		= '時間';
$lang['admin_log_ago_1zhou']	= '一周前';
$lang['admin_log_ago_1month']	= '一個月前';
$lang['admin_log_ago_2month']	= '兩個月前';
$lang['admin_log_ago_3month']	= '三個月前';
$lang['admin_log_ago_6month']	= '六個月前';
$lang['admin_log_tips1']		= '系統預設關閉了操作日誌，如需開啟，請使用EditPlus（禁止使用記事本、寫字板）編輯商城根目錄config.ini.php: $config[\'sys_log\'] = true;';
$lang['admin_log_tips2']		= '開啟操作日誌可以記錄管理人員的關鍵操作，但會輕微加重系統負擔';

