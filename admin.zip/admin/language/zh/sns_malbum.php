<?php
defined('In33hao') or exit('Access Invalid!');

$lang['snsalbum_album_setting']	= '相冊設置';
$lang['snsalbum_allow_upload_max_count']	= '允許上傳最大圖片數量';
$lang['snsalbum_allow_upload_max_count_tip']= '0為不限制';
$lang['snsalbum_pls_input_figures']			= '請填寫數字';
$lang['snsalbum_class_list']	= '相冊列表';
$lang['snsalbum_class_name']	= '相冊名稱';
$lang['snsalbum_member_name']	= '會員名稱';
$lang['snsalbum_add_time']		= '創建時間';
$lang['snsalbum_pic_count']		= '圖片數量';
$lang['snsalbum_pic_list']		= '圖片列表';
$lang['snsalbum_pic_name']		= '圖片名稱';
$lang['snsalbum_choose_need_del_img']		= '請選擇要刪除的圖片';