<?php
/**
 * 会员系统语言包
 */
defined('In33hao') or exit('Access Invalid!');

$lang['financial_daily_statement'] = '财务日报表';
$lang['financial_history_statement'] = '财务历史报表';

$lang['income_setting'] = '收益分配';
$lang['up_level_manage'] = '升级管理';